# Rodrigues Entregador V5 Final Base

App Android nativo Kotlin + Jetpack Compose exclusivo da Rodrigues Açaí e Cia.

Implementa base operacional: disponibilidade, ofertas Firestore, aceitar/rejeitar, coleta, retirada, entrega, histórico, ganhos, perfil, foreground service, notificação urgente e navegação externa.

Coloque o `google-services.json` em `app/google-services.json`.
