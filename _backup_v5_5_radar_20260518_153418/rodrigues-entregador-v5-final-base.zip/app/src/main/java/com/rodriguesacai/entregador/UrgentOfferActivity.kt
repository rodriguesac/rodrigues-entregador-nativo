package com.rodriguesacai.entregador
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.rodriguesacai.entregador.ui.RodriguesDriverApp
import com.rodriguesacai.entregador.ui.theme.RodriguesTheme
class UrgentOfferActivity:ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);setShowWhenLocked(true);setTurnScreenOn(true);setContent{RodriguesTheme{RodriguesDriverApp(forceOffer=true)}}}}
