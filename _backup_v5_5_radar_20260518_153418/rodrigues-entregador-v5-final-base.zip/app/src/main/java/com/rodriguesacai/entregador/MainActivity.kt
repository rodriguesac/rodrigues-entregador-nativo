package com.rodriguesacai.entregador
import android.Manifest
import android.content.Intent
import android.os.*
import androidx.activity.*
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import com.rodriguesacai.entregador.service.DriverForegroundService
import com.rodriguesacai.entregador.ui.RodriguesDriverApp
import com.rodriguesacai.entregador.ui.theme.RodriguesTheme
class MainActivity:ComponentActivity(){private val launcher=registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()){};override fun onCreate(b:Bundle?){super.onCreate(b); val ps= mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION); if(Build.VERSION.SDK_INT>=33)ps.add(Manifest.permission.POST_NOTIFICATIONS); launcher.launch(ps.toTypedArray()); startService(Intent(this,DriverForegroundService::class.java)); setContent{RodriguesTheme{RodriguesDriverApp()}}}}
