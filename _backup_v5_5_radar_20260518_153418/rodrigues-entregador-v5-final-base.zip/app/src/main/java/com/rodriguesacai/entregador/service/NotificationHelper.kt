package com.rodriguesacai.entregador.service
import android.app.*
import android.content.*
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import com.rodriguesacai.entregador.*
object NotificationHelper{const val CHANNEL_URGENT="corridas_urgentes";const val CHANNEL_SERVICE="servico_entregador"
 fun createChannels(c:Context){if(Build.VERSION.SDK_INT>=26){val nm=c.getSystemService(NotificationManager::class.java);val sound=Uri.parse("android.resource://${c.packageName}/${R.raw.alerta}");val attrs=AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();nm.createNotificationChannel(NotificationChannel(CHANNEL_URGENT,"Corridas urgentes",NotificationManager.IMPORTANCE_HIGH).apply{enableVibration(true);lockscreenVisibility=Notification.VISIBILITY_PUBLIC;setSound(sound,attrs)});nm.createNotificationChannel(NotificationChannel(CHANNEL_SERVICE,"Serviço do entregador",NotificationManager.IMPORTANCE_LOW))}}
 fun serviceNotification(c:Context):Notification{val pi=PendingIntent.getActivity(c,10,Intent(c,MainActivity::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE);return NotificationCompat.Builder(c,CHANNEL_SERVICE).setSmallIcon(R.drawable.ic_stat_delivery).setContentTitle("Rodrigues Entregador ativo").setContentText("Disponível para receber corridas.").setOngoing(true).setContentIntent(pi).build()}
 fun urgentRideNotification(c:Context,t:String,b:String):Notification{val pi=PendingIntent.getActivity(c,20,Intent(c,UrgentOfferActivity::class.java).apply{flags=Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP},PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE);return NotificationCompat.Builder(c,CHANNEL_URGENT).setSmallIcon(R.drawable.ic_stat_delivery).setContentTitle(t).setContentText(b).setPriority(NotificationCompat.PRIORITY_MAX).setCategory(NotificationCompat.CATEGORY_CALL).setVisibility(NotificationCompat.VISIBILITY_PUBLIC).setOngoing(true).setFullScreenIntent(pi,true).build()} }
