package com.rodriguesacai.entregador.service
import android.app.NotificationManager
import android.content.Context
import com.google.firebase.messaging.*
class RodriguesMessagingService:FirebaseMessagingService(){override fun onMessageReceived(m:RemoteMessage){NotificationHelper.createChannels(this);val nm=getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager;nm.notify(2001,NotificationHelper.urgentRideNotification(this,m.notification?.title?:m.data["title"]?:"Nova corrida",m.notification?.body?:m.data["body"]?:"Você recebeu uma nova oferta."))} override fun onNewToken(t:String){super.onNewToken(t)}}
