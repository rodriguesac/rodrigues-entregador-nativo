package com.rodriguesacai.entregador.ui.theme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
@Composable fun RodriguesTheme(content:@Composable()->Unit){MaterialTheme(colorScheme=darkColorScheme(background=Color(0xFF070B10),surface=Color(0xFF111923),primary=Color(0xFF22C55E),secondary=Color(0xFFEF233C),onBackground=Color.White,onSurface=Color.White),content=content)}
