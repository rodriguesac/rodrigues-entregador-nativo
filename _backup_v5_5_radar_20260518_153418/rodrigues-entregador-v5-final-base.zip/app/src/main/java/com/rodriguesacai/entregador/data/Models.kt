package com.rodriguesacai.entregador.data
enum class DriverStatus{INDISPONIVEL,DISPONIVEL,RESTRICAO,EM_OFERTA,INDO_COLETA,CHEGUEI_COLETA,PEDIDO_RETIRADO,INDO_ENTREGA,ENTREGUE}
data class RideOffer(val id:String="",val pedidoId:String="",val pedidoNumero:String="",val entregadorId:String="",val cliente:String="",val bairro:String="",val endereco:String="",val enderecoCompleto:String="",val itens:String="",val valorEntrega:Double=0.0,val totalPedido:Double=0.0,val distanciaKm:Double=0.0,val tempoMin:Int=0,val formaPagamento:String="",val status:String="enviada",val expiraEm:Long=0L)
data class RideState(val currentOffer:RideOffer?=null,val activeTab:String="home",val routeStep:DriverStatus=DriverStatus.INDISPONIVEL,val error:String?=null)
