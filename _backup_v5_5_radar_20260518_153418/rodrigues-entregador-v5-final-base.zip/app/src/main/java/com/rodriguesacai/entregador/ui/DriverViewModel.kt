package com.rodriguesacai.entregador.ui
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.firestore.ListenerRegistration
import com.rodriguesacai.entregador.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
class DriverViewModel(private val repo:FirebaseRepository=FirebaseRepository()):ViewModel(){private val _state=MutableStateFlow(RideState());val state:StateFlow<RideState> = _state; private var listener:ListenerRegistration?=null
 init{listener=repo.listenOffers({o-> if(o!=null)_state.value=_state.value.copy(currentOffer=o,routeStep=DriverStatus.EM_OFERTA)},{_state.value=_state.value.copy(error=it.message)})}
 fun setAvailable(v:Boolean)=viewModelScope.launch{repo.setDriverAvailable(v);_state.value=_state.value.copy(routeStep=if(v)DriverStatus.DISPONIVEL else DriverStatus.INDISPONIVEL)}
 fun accept(){val o=_state.value.currentOffer?:return;viewModelScope.launch{repo.acceptOffer(o);_state.value=_state.value.copy(routeStep=DriverStatus.INDO_COLETA)}}
 fun reject(m:String="Rejeitado"){val o=_state.value.currentOffer?:return;viewModelScope.launch{repo.rejectOffer(o,m);_state.value=_state.value.copy(currentOffer=null,routeStep=DriverStatus.DISPONIVEL)}}
 fun nextStep(){val o=_state.value.currentOffer?:return;val n=when(_state.value.routeStep){DriverStatus.INDO_COLETA->DriverStatus.CHEGUEI_COLETA;DriverStatus.CHEGUEI_COLETA->DriverStatus.PEDIDO_RETIRADO;DriverStatus.PEDIDO_RETIRADO->DriverStatus.INDO_ENTREGA;DriverStatus.INDO_ENTREGA->DriverStatus.ENTREGUE;else->DriverStatus.DISPONIVEL};viewModelScope.launch{when(n){DriverStatus.CHEGUEI_COLETA->repo.updateRideStep(o,"cheguei_na_coleta");DriverStatus.PEDIDO_RETIRADO->repo.updateRideStep(o,"pedido_retirado");DriverStatus.INDO_ENTREGA->repo.updateRideStep(o,"indo_entrega");DriverStatus.ENTREGUE->repo.finishRide(o);else->{}};_state.value=_state.value.copy(routeStep=n,currentOffer=if(n==DriverStatus.ENTREGUE)null else o)}}
 fun setTab(t:String){_state.value=_state.value.copy(activeTab=t)} override fun onCleared(){listener?.remove();super.onCleared()}}
