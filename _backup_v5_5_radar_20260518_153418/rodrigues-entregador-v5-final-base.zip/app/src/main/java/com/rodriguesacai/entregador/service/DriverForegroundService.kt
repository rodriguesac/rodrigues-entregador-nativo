package com.rodriguesacai.entregador.service
import android.app.Service
import android.content.Intent
import android.os.IBinder
class DriverForegroundService:Service(){override fun onCreate(){super.onCreate();NotificationHelper.createChannels(this);startForeground(1001,NotificationHelper.serviceNotification(this))} override fun onStartCommand(i:Intent?,f:Int,s:Int):Int{startForeground(1001,NotificationHelper.serviceNotification(this));return START_STICKY} override fun onBind(i:Intent?):IBinder?=null}
